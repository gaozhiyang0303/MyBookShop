﻿using Czar.Cms.Core.Repository;
using Gzy.BookShop.Core;
using Gzy.BookShop.Core.Option;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.Model.Sys;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Czar.Cms.Test
{
    public class Common
    {
        /// <summary>
        /// 构造依赖注入容器，然后传入参数
        /// </summary>
        /// <returns></returns>
        public static IServiceProvider BuildServiceForSqlServer()
        {
            var services = new ServiceCollection();
            services.Configure<DbOption>(options =>
            {
                options.ConnectionString = "Data Source=.;Initial Catalog=Gzy.NetCore.BookShop;User ID=sa;Password=123456;Persist Security Info=True;Max Pool Size=50;Min Pool Size=0;Connection Lifetime=300;";
                options.DbType = DatabaseType.SqlServer.ToString();//数据库类型是SqlServer,其他数据类型参照枚举DatabaseType
               
                


            });
            services.Configure<DbOption>("Gzy.NetCore.BookShop", GetConfiguration().GetSection("DbOpion"));
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            return services.BuildServiceProvider(); //构建服务提供程序
        }

        public static IConfiguration GetConfiguration()
        {
            var builder = new ConfigurationBuilder()
               .SetBasePath(AppContext.BaseDirectory)
               .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables();
            return builder.Build();
        }
    }
}
