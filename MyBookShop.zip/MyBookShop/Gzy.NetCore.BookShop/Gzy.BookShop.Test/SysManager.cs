﻿using System;
using System.Net.Mail;
using Czar.Cms.Test;
using Czar.Cms.Core.Repository;
using Gzy.BookShop.Model.Sys;
using Xunit;
using Microsoft.Extensions.DependencyInjection;
using Gzy.BookShop.Core;
using Gzy.CorePublic;
using System.Data.SqlClient;
using Dapper;

namespace Gzy.BookShop.Test
{
    public class SysManager
    {
        [Fact]
        public void AddManager()
        {
            var con = new Manager()
            {
                
                //DeFlag = false,
                //Version = 1,
                //OptDate = DateTime.Now,
                //OptUser = "gzy",
                //LoginName = "admin",
                //NickName = "花儿为什么这样红",
                //PassWord = GzyCryptography.GetMd5Hash("123456"),
                //Avatar = "",
                //Mobile = "18222937244",
                //Email = "928804909@qq.com",
                //LoginLastIp = "",
                //LoginLastTime = null,
                //CreatTime = DateTime.Now,
                //IsLock = false,
                //ManagerRoleId = Guid.Empty
            };
            var serviceProvider = Common.BuildServiceForSqlServer();
            var unitwork = serviceProvider.GetService<IUnitOfWork>();
            var count = 0;
            try
            {
                unitwork.Add(con);
                unitwork.Commit();
            }
            catch (Exception e)
            {

            }
        }
        [Fact]
        public void AddManager2()
        {
            var con = new Manager()
            {

                DeFlag = false,
                Version = 1,
                OptDate = DateTime.Now,
                OptUser = "gzy",
                LoginName = "admin",
                NickName = "花儿为什么这样红",
                PassWord = "123456",
                Avatar = "1",
                Mobile = "18222937244",
                Email = "928804909@qq.com",
                LoginLastIp = "",
                LoginLastTime = null,
                CreatTime = DateTime.Now,
                IsLock = false,
                ManagerRoleId = 1
            };
            using (var conne = new SqlConnection(@"server=.;uid=sa;pwd=123456;database=Gzy.NetCore.BookShop;"))
            {
                
                conne.Insert(con);
            }
        }


    }


}
