﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Gzy.BookShop.Test
{
    public class Test
    {
        [Fact]
        public void CreateEntity()
        {
            
        }

    }
}
