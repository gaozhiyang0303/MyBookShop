﻿using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.BookShop.ViewModel.RolePermission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gzy.BookShop.Service.Sys
{
    public class RolePermissionService : IRolePermissionService
    {
        private readonly IFuncUnitRepository _repository;
        private readonly IRolePermissionRepository _permissionRepository;
        public RolePermissionService(IFuncUnitRepository repository, IRolePermissionRepository permissionRepository)
        {
            _repository = repository;
            _permissionRepository = permissionRepository;

        }
        public TableDataModel GetRoleFuncUnits(int roleId)
        {
            var da=new List<RoleFuncUnitModels>();
            string funcsql = "where DeFlag=0 and ParentFuncUnitId!=0";//把父级筛掉
            var funcUnits = _repository.GetList(funcsql);
            string roleFuncUntisql = $"where DeFlag=0 and RoleId='{roleId}'";
            var checkFuncUntiId = _permissionRepository.GetList(roleFuncUntisql).Select(p=>p.FuncUnitId);
            var checkFunc = funcUnits.Where(p => checkFuncUntiId.Contains(p.ID)).Select(p=>new RoleFuncUnitModels()
            {
                Id = p.ID,
                ParentFuncUnitId = p.ParentFuncUnitId,
                ParentName = _repository.Get(p.ParentFuncUnitId)?.DisplayName,
                Name = p.Name,
                DisplayName = p.DisplayName,
                IconUrl = p.IconUrl,
                LinkUrl = p.LinkUrl,
                Sort = p.Sort,
                LAY_CHECKED = true
            });
            var ischeckFunc= funcUnits.Where(p => !checkFuncUntiId.Contains(p.ID)).Select(p=>new RoleFuncUnitModels()
            {
                Id = p.ID,
                ParentFuncUnitId = p.ParentFuncUnitId,
                ParentName = _repository.Get(p.ParentFuncUnitId)?.DisplayName,
                Name = p.Name,
                DisplayName = p.DisplayName,
                IconUrl = p.IconUrl,
                LinkUrl = p.LinkUrl,
                Sort = p.Sort,
                LAY_CHECKED = false
            });
            da.AddRange(checkFunc);
            da.AddRange(ischeckFunc);
            return new TableDataModel
            {
                count = da.Count,//查询数据量
                data = da
            };

        }

        public BaseResult RoleBindingFunc(int[] ids,int roleid)
        {
            var result=new BaseResult();
            var querysql = $"where DeFlag=0 and RoleId='{roleid}'";
            if (!_permissionRepository.DeleteList(querysql))
            {
                result.ResultCode = 2;
                result.ResultMsg = "失败，服务器错误,请重新操作";
            }

            var count=_permissionRepository.InsertList(ids, roleid);
            if (count <= 0)
            {
                result.ResultCode = 2;
                result.ResultMsg = "失败，服务器错误,请重新操作";
            }

            return result;
        }
    }
}
