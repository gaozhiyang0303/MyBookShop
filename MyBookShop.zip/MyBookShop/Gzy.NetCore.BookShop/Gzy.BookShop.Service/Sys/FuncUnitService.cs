﻿using AutoMapper;
using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.ResultModel;
using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.ViewModel.FuncUnit;
using Gzy.BookShop.Core.Extensions;
using System.Linq;
using Gzy.BookShop.Model.Sys;

namespace Gzy.BookShop.Service.Sys
{
    public class FuncUnitService: IFuncUnitService
    {
        private readonly IFuncUnitRepository _repository;
        public FuncUnitService(IFuncUnitRepository repository)
        {
            _repository = repository;

        }

        

        public TableDataModel LoadData(FuncUnitRequestModel model)
        {
            string conditions = "where DeFlag=0 ";//未删除的
            if (!model.Key.IsNullOrWhiteSpace())
            {
                conditions += $"and DisplayName like '%{model.Key}%'";
            }

            var datas =  _repository.GetListPaged(model.Page, model.Limit, conditions, "ID", new
            {
                Key = model.Key,
            });
            return new TableDataModel
            {
                count = _repository.RecordCount(conditions),//查询数据量
                data = datas.Select(p=>new FuncUnitAddOrModifyModel()
                {
                    Id = p.ID,
                    ParentFuncUnitId = p.ParentFuncUnitId,
                    ParentName = _repository.Get(p.ParentFuncUnitId)?.DisplayName,
                    Name=p.Name,
                    DisplayName=p.DisplayName,
                    IconUrl=p.IconUrl,
                    LinkUrl=p.LinkUrl,
                    Sort=p.Sort,
                   
                }).ToList(),//查询总数
            };
        }
        public List<FuncUnit> GetChildListByParentId()
        {
            string conditions = "where DeFlag=0 and ParentFuncUnitId =0";
          
            var data= _repository.GetList(conditions).ToList();
            return data;
        }

        public BaseResult AddOrModify(FuncUnitAddOrModifyModel mode)
        {
            var result=new BaseResult();
            
            if (mode.Id == 0)
            {
                //新增
                var model = new FuncUnit()
                {
                    DeFlag = false,
                    Version = 1,
                    OptUser = "admin",
                    OptDate = DateTime.Now,
                    Name = mode.Name,
                    DisplayName = mode.DisplayName,
                    ParentFuncUnitId = mode.ParentFuncUnitId,
                    IconUrl = mode.IconUrl == null ? "" : mode.IconUrl,
                    LinkUrl = mode.LinkUrl,
                    Sort = mode.Sort,
          

                };              
                if (_repository.Insert(model))
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonObjectSuccessCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonObjectSuccessMsg;
                }
                else
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonExceptionCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonExceptionMsg;
                }
            }
            else
            {
                //TODO Modify
                var model = _repository.Get(mode.Id);
                if (model != null)
                {
                   
                    
                    model.OptDate = DateTime.Now;
                    model.Version = model.Version + 1;
                    model.Name = mode.Name;
                    model.DisplayName = mode.DisplayName;
                    model.ParentFuncUnitId = mode.ParentFuncUnitId;
                    model.IconUrl = mode.IconUrl==null?"": mode.IconUrl;
                    model.LinkUrl = mode.LinkUrl;
                    model.Sort = mode.Sort;
               
                    if(_repository.Update(model))
                    {
                        result.ResultCode = ResultCodeAddMsgKeys.CommonObjectSuccessCode;
                        result.ResultMsg = ResultCodeAddMsgKeys.CommonObjectSuccessMsg;
                    }
                    else
                    {
                        result.ResultCode = ResultCodeAddMsgKeys.CommonExceptionCode;
                        result.ResultMsg = ResultCodeAddMsgKeys.CommonExceptionMsg;
                    }
                }
                else
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonFailNoDataCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonFailNoDataMsg;
                }
            }

            return result;
        }

        public BooleanResult IsExistsName(FuncUnitAddOrModifyModel item)
        {
            bool data = false;
            if (item.Id > 0)
            {
                //修改判断
                data = _repository.IsExistsName(item.Name, item.Id);
            }
            else
            {
                data = _repository.IsExistsName(item.Name);
            }

            var result = new BooleanResult
            {
                Data = data,
            };
            return result;
        }

        public BaseResult DeleteIds(int[] ids)
        {
            var result=new BaseResult();
            if (ids.Count() == 0)
            {
                result.ResultCode = ResultCodeAddMsgKeys.CommonModelStateInvalidCode;
                result.ResultMsg = ResultCodeAddMsgKeys.CommonModelStateInvalidMsg;
            }
            else
            {
                var count = _repository.DeleteIds(ids);
                if (count > 0)
                {
                    //成功
                    result.ResultCode = ResultCodeAddMsgKeys.CommonObjectSuccessCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonObjectSuccessMsg;
                }
                else
                {
                    //失败
                    result.ResultCode = ResultCodeAddMsgKeys.CommonExceptionCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonExceptionMsg;
                }
            }

            return result;
        }
    }
}
