﻿using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.FuncUnit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gzy.BookShop.IRepository.Sys;
using AutoMapper;
using Gzy.BookShop.Core;
using Gzy.BookShop.Core.Extensions;
using Gzy.BookShop.Model.Sys;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.BookShop.ViewModel.Role;

namespace Gzy.BookShop.Service.Sys
{
    public class ManagerRoleService : IManagerRoleService
    {
        private IManagerRoleRepository _repository;
      
        public ManagerRoleService(IManagerRoleRepository repository)
        {
            _repository = repository;
        }
        public List<FuncUnitNavView> GetFuncUnitsByRoleId(int roleId)
        {
            
            var datas = _repository.GetFuncUnitNav(roleId).Select(p=>new FuncUnitNavView()
            {
                Id = p.ID,
                ParentId = p.ParentFuncUnitId,
                Name = p.Name,
                DisplayName = p.DisplayName,
                IconUrl = p.IconUrl,
                LinkUrl = p.LinkUrl,
                Spread = false,
                Target ="",
            }).ToList();              
            return datas;
        }

        public TableDataModel GetRoleList(RoleRequestModel model)
        {
            string sql = "where DeFlag=0";
            if (!model.Key.IsNullOrEmpty())
            {
                sql += $"and RoleName like '%{model.Key}%'";
            }

            var datas = _repository.GetListPaged(model.Page, model.Limit, sql, "ID", new {Key = model.Key});
            var tableData=new TableDataModel()
            {
                count = _repository.RecordCount(sql),
                data = datas.Select(p=>new RoleViewModel()
                {
                    ID = p.ID,
                    RoleName=p.RoleName,
                    RoleType = p.RoleType,
                    CreatTime = p.CreatTime,
                    Remark = p.Remark

                })
            };
            return tableData;
        }

        public IEnumerable<ManagerRole> GetRoleViewModels()
        {
            var sql = "where DeFlag=0";
            var datas = _repository.GetList(sql);
            return datas;
        }

        /// <summary>
        /// 新增或者修改
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public BaseResult SaveOrUpdateRole(RoleViewModel item)
        {
            var res=new BaseResult();
            var isExists  =_repository.IsExistsRoleName(item.RoleName, item.ID);
            if (isExists != 0)
            {
                if (isExists == 1)
                {
                    res.ResultCode = 1;
                    res.ResultMsg = "角色名称重复,修改失败";
                    return res;
                }

                if (isExists == 2)
                {
                    res.ResultCode = 2;
                    res.ResultMsg = "角色名称重复,添加失败";
                    return res;
                }
            }
            //验证成功
            var role = new ManagerRole()
            {
                Version = 1,
                DeFlag = false,
                OptUser = "gzy",
                OptDate = DateTime.Now,
                RoleName = item.RoleName,
                RoleType = item.RoleType,
                Remark = item.Remark,
                CreatTime = DateTime.Now,
            };
            _repository.Insert(role);
            return res;
        }
    }
}
