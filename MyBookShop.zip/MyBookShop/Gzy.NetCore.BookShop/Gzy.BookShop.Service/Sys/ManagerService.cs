﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gzy.BookShop.Core.Extensions;
using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.Model.Sys;
using Gzy.BookShop.ViewModel.Account;
using Gzy.BookShop.ViewModel.Manager;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.CorePublic;

namespace Gzy.BookShop.Service.Sys
{
    public class ManagerService:IManagerService
    {
        private IManagerRepository _repository;
        private IManagerLogRepository _logrepository;
        private IManagerRoleRepository _rolerepository;
        public ManagerService(IManagerRepository repository, IManagerLogRepository logrepository, IManagerRoleRepository rolerepository)
        {
            _repository = repository;
            _logrepository = logrepository;
            _rolerepository = rolerepository;
        }

        public BaseResult AddOrUpdateManager(ManagerListModel p)
        {
            var result = new BaseResult();
            p.PassWord = GzyCryptography.GetMd5Hash(p.PassWord.Trim());
            if (p.ID == 0)
            {
                
                //新增
                var manager=new Manager()
                {
                    ID = p.ID,
                    DeFlag = false,
                    Version = 1,
                    CreatTime = DateTime.Now,
                    OptUser = "Gzy",
                    OptDate = DateTime.Now,
                    LoginName = p.LoginName,
                    PassWord = p.PassWord,
                    NickName = p.NickName,
                    Mobile=p.Mobile,
                    Email = p.Email,
                    ManagerRoleId = p.ManagerRoleId,
                    IsLock = p.IsLock,
                    Remark = p.Remark
                };
                if (_repository.Insert(manager))
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonObjectSuccessCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonObjectSuccessMsg;
                }
                else
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonExceptionCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonExceptionMsg;
                }
            }
            else
            {
                string sql = $"where DeFlag=0 and ID={p.ID}";
                //修改
                var manager = _repository.GetList(sql).FirstOrDefault();
                if (manager != null)
                {
                    manager.Version = manager.Version + 1;
                    manager.OptDate=DateTime.Now;
                    manager.LoginName = p.LoginName;
                    manager.PassWord = p.PassWord;
                    manager.NickName = p.NickName;
                    manager.Mobile = p.Mobile;
                    manager.Email = p.Email;
                    manager.ManagerRoleId = p.ManagerRoleId;
                    manager.IsLock = p.IsLock;
                    manager.Remark = p.Remark;
                    if (_repository.Update(manager))
                    {
                        result.ResultCode = ResultCodeAddMsgKeys.CommonObjectSuccessCode;
                        result.ResultMsg = ResultCodeAddMsgKeys.CommonObjectSuccessMsg;
                    }
                    else
                    {
                        result.ResultCode = ResultCodeAddMsgKeys.CommonExceptionCode;
                        result.ResultMsg = ResultCodeAddMsgKeys.CommonExceptionMsg;
                    }
                }
                else
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonFailNoDataCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonFailNoDataMsg;
                }
            }

            return result;
        }

        public Manager GetManagerById(int id)
        {
           return _repository.GetManagerById(id);
        }

        public bool IsExistsLoginName(string Name, int ID)
        {
            return _repository.IsExistsLoginName(Name, ID);
        }

        public TableDataModel LoadData(ManagerRequestModel model)
        {
            var sql = "where DeFlag=0";
            if (!model.Key.IsNullOrWhiteSpace())
            {
                sql += $"and LoginName like '%{model.Key}%'";
            }

            var managers = _repository.GetListPaged(model.Page, model.Limit, sql, "ID");
            var datas = managers.Select(p => new ManagerListModel()
            {
                ID = p.ID,
                LoginName = p.LoginName,
                PassWord=p.PassWord,
                NickName = p.NickName,
                Avatar = p.Avatar,
                Mobile = p.Mobile,
                Email = p.Email,
                LoginLastIp = p.LoginLastIp,
                LoginLastTime = p.LoginLastTime,
                CreatTime = p.CreatTime,
                IsLock = p.IsLock,
                ManagerRoleId = p.ManagerRoleId,
                ManagerRoleName = _rolerepository.Get(p.ManagerRoleId)?.RoleName,
                Remark = p.Remark,
            });
            return new TableDataModel()
            {
                count = _repository.RecordCount(sql),
                data = datas
            };
        }

        public Manager SignIn(LoginViewModel model)
        {
            model.Password = GzyCryptography.GetMd5Hash(model.Password.Trim());
            model.UserName = model.UserName.Trim();
            //var sql = "where DeFlag=0 and LoginName=@UserName and PassWord=@Password";
            string conditions = "where DeFlag=0 ";//未删除的
            conditions += $"and (LoginName = @UserName) and Password=@Password";
            var manager = _repository.GetList(conditions, new
            {
                UserName=model.UserName,
                Password=model.Password
            }).FirstOrDefault();
            if (manager != null)
            {
                manager.OptDate=DateTime.Now;
                manager.Version += 1;
                manager.LoginLastIp = model.Ip;
                manager.LoginLastTime=DateTime.Now;
                if (_repository.Update(manager))
                {
                    var managerlog = new ManagerLog()
                    {
                        Version = 1,
                        DeFlag = false,
                        OptUser = model.UserName,
                        OptDate = DateTime.Now,
                        ActionType = "登陆",
                        AddManageId = manager.ID,
                        AddManagerNickName = manager.NickName,
                        AddTime = DateTime.Now,
                        AddIp = model.Ip,
                        Remark = "用户登陆"
                    };
                    _logrepository.Insert(managerlog);
                }
                
            }

            return manager;
        }

        public BaseResult UpdateManagerInfo(ChangeManagerInfo changeManagerInfo)
        {
            var result = new BaseResult();
            string sql = $"where DeFlag=0 and ID={changeManagerInfo.ID}";
            //修改
            var manager = _repository.GetList(sql).FirstOrDefault();
            if (manager != null)
            {
                manager.Version = manager.Version + 1;
                manager.OptDate = DateTime.Now;
                manager.LoginName = changeManagerInfo.LoginName;
                manager.NickName = changeManagerInfo.NickName;
                manager.Mobile = changeManagerInfo.Mobile;
                manager.Email = changeManagerInfo.Email;
                manager.Avatar = changeManagerInfo.Avatar;
                manager.Remark = changeManagerInfo.Remark;
                if (_repository.Update(manager))
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonObjectSuccessCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonObjectSuccessMsg;
                }
                else
                {
                    result.ResultCode = ResultCodeAddMsgKeys.CommonExceptionCode;
                    result.ResultMsg = ResultCodeAddMsgKeys.CommonExceptionMsg;
                }
            }
            else
            {
                result.ResultCode = ResultCodeAddMsgKeys.CommonFailNoDataCode;
                result.ResultMsg = ResultCodeAddMsgKeys.CommonFailNoDataMsg;
            }

            return result;
        }
    }
}
