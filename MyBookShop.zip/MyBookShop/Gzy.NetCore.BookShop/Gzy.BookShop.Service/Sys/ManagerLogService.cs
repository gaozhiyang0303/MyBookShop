﻿using Gzy.BookShop.IService.Sys;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.Service.Sys
{
    public class ManagerLogService: IManagerLogService
    {

    }
}
