﻿using Dapper;
using Gzy.BookShop.Core.Option;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Gzy.BookShop.Core.Repository
{
    public class BaseRepository<T, TKey> : IBaseRepository<T, TKey> where T : class
    {
        protected DbOption _dbOption;
        protected IDbConnection _dbConnection;
        #region 同步
        public T Get(TKey id)
        {
            var data = _dbConnection.Get<T>(id);
            return data;
        }
        public IEnumerable<T> GetList()
        {
            var data = _dbConnection.GetList<T>();
            return data;
        }

        public IEnumerable<T> GetList(object whereConditions)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetList(string conditions, object parameters = null)
        {
            var data = _dbConnection.GetList<T>(conditions, parameters);
            return data;
        }
        public bool Delete(TKey id)
        {
            throw new NotImplementedException();
        }
        public bool Update(T entity)
        {
            if(_dbConnection.Update(entity) > 0)
            {
                return true;
            }

            return false;
        }
        public bool Delete(T entity)
        {
            throw new NotImplementedException();
        }
        public bool DeleteList(object whereConditions, IDbTransaction transaction = null, int? commandTimeout = null)
        {
            throw new NotImplementedException();
        }

        public bool DeleteList(string conditions, object parameters = null, IDbTransaction transaction = null, int? commandTimeout = null)
        {
           var count= _dbConnection.DeleteList<T>(conditions, parameters, transaction, commandTimeout);
           if (count >= 0)
           {
               return true;
           }

           return false;
        }
        public IEnumerable<T> GetListPaged(int pageNumber, int rowsPerPage, string conditions, string orderby, object parameters = null)
        {
            var data = _dbConnection.GetListPaged<T>(pageNumber, rowsPerPage, conditions, orderby, parameters);
            return data;
        }



        public bool Insert(T entity)
        {
            var aa=_dbConnection.Insert(entity);
            if (aa != 0)
            {
                return true;
            }

            return false;
        }


        public int RecordCount(string conditions = "", object parameters = null)
        {
            return _dbConnection.RecordCount<T>(conditions, parameters);
        }

        #endregion
    
        #region 异步
        public Task<IEnumerable<T>> GetListAsync()
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<T>> GetListAsync(object whereConditions)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<T>> GetListAsync(string conditions, object parameters = null)
        {
            throw new NotImplementedException();
        }
        public Task<T> GetAsync(TKey id)
        {
            throw new NotImplementedException();
        }
        public Task<IEnumerable<T>> GetListPagedAsync(int pageNumber, int rowsPerPage, string conditions, string orderby, object parameters = null)
        {
            throw new NotImplementedException();
        }
        public Task<bool> InsertAsync(T entity)
        {
            throw new NotImplementedException();
        }

        public Task<int> RecordCountAsync(string conditions = "", object parameters = null)
        {
            throw new NotImplementedException();
        }
        public Task<bool> UpdateAsync(T entity)
        {
            throw new NotImplementedException();
        }
        public Task<bool> DeleteAsync(TKey id)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteAsync(T entity)
        {
            throw new NotImplementedException();
        }



        public Task<bool> DeleteListAsync(object whereConditions, IDbTransaction transaction = null, int? commandTimeout = null)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteListAsync(string conditions, object parameters = null, IDbTransaction transaction = null, int? commandTimeout = null)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IDisposable Support
        private bool disposedValue = false; // 要检测冗余调用

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 释放托管状态(托管对象)。
                    _dbConnection?.Dispose();
                }

                // TODO: 释放未托管的资源(未托管的对象)并在以下内容中替代终结器。
                // TODO: 将大型字段设置为 null。

                disposedValue = true;
            }
        }

        // TODO: 仅当以上 Dispose(bool disposing) 拥有用于释放未托管资源的代码时才替代终结器。
        // ~BaseRepository() {
        //   // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
        //   Dispose(false);
        // }

        // 添加此代码以正确实现可处置模式。
        public void Dispose()
        {
            // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
            Dispose(true);
            // TODO: 如果在以上内容中替代了终结器，则取消注释以下行。
            // GC.SuppressFinalize(this);
        }



        #endregion
    }
}
