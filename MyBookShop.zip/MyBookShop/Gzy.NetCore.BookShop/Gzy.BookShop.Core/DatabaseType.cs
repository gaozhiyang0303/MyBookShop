﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.Core
{
    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum DatabaseType
    {
        SqlServer,
        MySQL,
        Oracle,
        SQLite,
    }
}
