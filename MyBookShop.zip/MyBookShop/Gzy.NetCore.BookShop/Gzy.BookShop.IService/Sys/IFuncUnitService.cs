﻿using Gzy.BookShop.ViewModel.FuncUnit;
using Gzy.BookShop.ViewModel.ResultModel;
using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.Model.Sys;

namespace Gzy.BookShop.IService.Sys
{
    public interface IFuncUnitService
    {
        /// <summary>
        /// 根据条件查询实体
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        TableDataModel LoadData(FuncUnitRequestModel model);

        /// <summary>
        /// 根据父节点返回列表
        /// </summary>
        /// <param name="ParentId"></param>
        /// <returns></returns>
        List<FuncUnit> GetChildListByParentId();

        /// <summary>
        /// 新增或者修改服务
        /// </summary>
        /// <param name="mode"></param>
        /// <returns></returns>
        BaseResult AddOrModify(FuncUnitAddOrModifyModel mode);
        /// <summary>
        /// 判断菜单名称是否存在
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        BooleanResult IsExistsName(FuncUnitAddOrModifyModel item);
        /// <summary>
        /// 批量删除
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        BaseResult DeleteIds(int[] ids);
    }
}
