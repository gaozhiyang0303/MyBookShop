﻿using Gzy.BookShop.Model.Sys;
using Gzy.BookShop.ViewModel.Account;
using Gzy.BookShop.ViewModel.Manager;
using Gzy.BookShop.ViewModel.ResultModel;


namespace Gzy.BookShop.IService.Sys
{
    public interface IManagerService
    {
        /// <summary>
        /// 登陆并返回对顶用户数据,并写登陆日志，和更改Manager中的IP和最后一次登陆事件
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Manager SignIn(LoginViewModel model);

        TableDataModel LoadData(ManagerRequestModel model);

        /// <summary>
        /// 校验登录名是否重复
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="ID"></param>
        /// <returns></returns>
        bool IsExistsLoginName(string Name, int ID);

        BaseResult AddOrUpdateManager(ManagerListModel managerListModel);

        Manager GetManagerById(int id);

        BaseResult UpdateManagerInfo(ChangeManagerInfo changeManagerInfo);
    }
}
