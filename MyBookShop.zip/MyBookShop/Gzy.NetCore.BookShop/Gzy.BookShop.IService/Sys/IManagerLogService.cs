﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.IService.Sys
{
    public interface IManagerLogService
    {
    }
}
