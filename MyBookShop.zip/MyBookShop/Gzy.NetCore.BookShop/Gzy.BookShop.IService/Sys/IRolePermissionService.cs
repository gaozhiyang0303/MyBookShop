﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.ViewModel.ResultModel;

namespace Gzy.BookShop.IService.Sys
{
    public interface IRolePermissionService
    {
        TableDataModel GetRoleFuncUnits(int roleId);

        /// <summary>
        /// 角色和页面绑定
        /// </summary>
        /// <returns></returns>
        BaseResult RoleBindingFunc(int[] ids, int roleid);
    }
}
