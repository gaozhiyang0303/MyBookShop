﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.Model.Sys;
using Gzy.BookShop.ViewModel.FuncUnit;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.BookShop.ViewModel.Role;

namespace Gzy.BookShop.IService.Sys
{
    public interface IManagerRoleService
    {
        /// <summary>
        /// 通过角色ID获取角色分配的菜单栏
        /// </summary>
        /// <param name="roleId"></param>
        /// <returns></returns>
        List<FuncUnitNavView> GetFuncUnitsByRoleId(int roleId);
        /// <summary>
        /// 查询角色 分页 根据角色名称条件查询
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        TableDataModel GetRoleList(RoleRequestModel model);

        BaseResult SaveOrUpdateRole(RoleViewModel item);

        IEnumerable<ManagerRole> GetRoleViewModels();
    }
}
