﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Gzy.BookShop.Core.DbHelper;
using Gzy.BookShop.Core.Option;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.Model.Sys;
using Microsoft.Extensions.Options;

namespace Gzy.BookShop.Repository.SqlServer.Sys
{
    public class ManagerRoleRepository:BaseRepository<ManagerRole,int>,IManagerRoleRepository
    {
        public ManagerRoleRepository(IOptionsSnapshot<DbOption> options)
        {
            //获取注册时获取的数据库类型和连接字段
            _dbOption = options.Get("Gzy.NetCore.BookShop");
            if (_dbOption == null)
            {
                throw new ArgumentNullException(nameof(options));
            }
            //调用数据库工厂类创建数据库连接通道
            _dbConnection = ConnectionFactory.CreateConnection(_dbOption.DbType, _dbOption.ConnectionString);
        }

        public IEnumerable<FuncUnit> GetFuncUnitNav(int roleId)
        {
            var da=new List<string>();
            var sql = $"SELECT fu.* FROM [RolePermission] rp join FuncUnit fu on rp.FuncUnitId = fu.ID and rp.RoleId = {roleId}";
            var datas = _dbConnection.Query<FuncUnit>(sql);
            var ids = datas.Select(p => p.ID);
            foreach (var id in ids)
            {
              da.Add(id.ToString());
            }
            var pareIds = datas.Select(p => p.ParentFuncUnitId).Distinct();
            foreach (var pareId in pareIds)
            {
                da.Add(pareId.ToString());
            }

            string aa = string.Join(',',da);
            string sql1 = $"select * from FuncUnit where ID in ({aa})";
            var data = _dbConnection.Query<FuncUnit>(sql1);
            return data;
        }

        public class Data
        {
            public int ID { get; set; }
        }
        public int IsExistsRoleName(string rolename,int Id)
        {
            var sql = "";
            if (Id > 0)
            {
                //修改
                sql = $"Select * from ManagerRole where DeFlag=0 and ID!='{Id}' and RoleName='{rolename}'";
                var res = _dbConnection.Query<int>(sql);
                if (res != null || res.Count() > 0)
                {
                    return 1;
                }
            }
            else
            {
                //新增
                sql = $"Select * from ManagerRole where DeFlag=0 and RoleName='{rolename}'";
                var res = _dbConnection.Query<int>(sql);
                if (res!=null||res.Count()>0)
                {
                    return 2;
                }
            }

            return 0;

        }
    }
}
