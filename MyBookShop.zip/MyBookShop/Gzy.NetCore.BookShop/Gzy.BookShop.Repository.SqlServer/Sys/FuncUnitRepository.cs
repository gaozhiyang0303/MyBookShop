﻿using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.Model.Sys;
using System;
using System.Linq;
using Dapper;
using Gzy.BookShop.IRepository.Sys;
using Microsoft.Extensions.Options;
using Gzy.BookShop.Core.Option;
using Gzy.BookShop.Core.DbHelper;

namespace Gzy.BookShop.Repository.SqlServer.Sys
{
    public class FuncUnitRepository: BaseRepository<FuncUnit, int>,IFuncUnitRepository
    {
        public FuncUnitRepository(IOptionsSnapshot<DbOption> options)
        {
            //获取注册时获取的数据库类型和连接字段
            _dbOption = options.Get("Gzy.NetCore.BookShop");
            if (_dbOption == null)
            {
                throw new ArgumentNullException(nameof(options));
            }
            //调用数据库工厂类创建数据库连接通道
            _dbConnection = ConnectionFactory.CreateConnection(_dbOption.DbType, _dbOption.ConnectionString);
        }

        public int DeleteIds(int[] ids)
        {
            string sql = "update FuncUnit set DeFlag=1 where Id in @Ids";
            return _dbConnection.Execute(sql, new
            {
                Ids = ids
            });
        }

        public bool IsExistsName(string Name, int Id)
        {
            string sql = "select Id from FuncUnit where Name=@Name and Id<>@Id and DeFlag=0";
            var result = _dbConnection.Query<int>(sql, new
            {
                Name = Name,
                Id = Id
            });
            if (result != null && result.Count() > 0)
            {
                return true;//说明存在
            }
            else
            {
                return false;
            }
        }

        public bool IsExistsName(string Name)
        {
            string sql = "select Id from FuncUnit where Name=@Name  and DeFlag=0";
            var result = _dbConnection.Query<int>(sql, new
            {
                Name = Name,
                
            });
            if (result != null && result.Count() > 0)
            {
                return true;//说明存在
            }
            else
            {
                return false;
            }
        }
    }
}
