﻿using System;
using System.Collections.Generic;
using System.Text;
using Dapper;
using Gzy.BookShop.Core.DbHelper;
using Gzy.BookShop.Core.Option;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.Model.Sys;
using Microsoft.Extensions.Options;

namespace Gzy.BookShop.Repository.SqlServer.Sys
{
    public class RolePermissionRepository:BaseRepository<RolePermission,int>, IRolePermissionRepository
    {
        public RolePermissionRepository(IOptionsSnapshot<DbOption> options)
        {
            //获取注册时获取的数据库类型和连接字段
            _dbOption = options.Get("Gzy.NetCore.BookShop");
            if (_dbOption == null)
            {
                throw new ArgumentNullException(nameof(options));
            }
            //调用数据库工厂类创建数据库连接通道
            _dbConnection = ConnectionFactory.CreateConnection(_dbOption.DbType, _dbOption.ConnectionString);
        }

        public int InsertList(int[] ids, int roleid)
        {
            var sql =
                "Insert into [RolePermission] (DeFlag,Version,OptDate,OptUser,RoleId,FuncUnitId) Values (0,1,@OptDate,@OptUser,@RoleId,@FuncUnitId)";
            var da=new List<RolePermission>();
            foreach (var id in ids)
            {
                da.Add(new RolePermission()
                {
                    Version = 1,
                    DeFlag = false,
                    OptDate = DateTime.Now,
                    OptUser = "GZY",
                    RoleId = roleid,
                    FuncUnitId = id

                });
            }

            var count = _dbConnection.Execute(sql, da);
            return count;
        }
    }
}
