﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using Gzy.BookShop.Core.DbHelper;
using Gzy.BookShop.Core.Option;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.Model.Sys;
using Microsoft.Extensions.Options;

namespace Gzy.BookShop.Repository.SqlServer.Sys
{

    public class ManagerRepository:BaseRepository<Manager,int>,IManagerRepository
    {
        public ManagerRepository(IOptionsSnapshot<DbOption> options)
        {
            //获取注册时获取的数据库类型和连接字段
            _dbOption = options.Get("Gzy.NetCore.BookShop");
            if (_dbOption == null)
            {
                throw new ArgumentNullException(nameof(options));
            }
            //调用数据库工厂类创建数据库连接通道
            _dbConnection = ConnectionFactory.CreateConnection(_dbOption.DbType, _dbOption.ConnectionString);
        }

        public Manager GetManagerById(int Id)
        {
            var sql =
                $"select * from Manager where DeFlag=0 and ID={Id}";
            var manager = _dbConnection.QueryFirstOrDefault<Manager>(sql);
            return manager;
        }

        public bool IsExistsLoginName(string name, int id)
        {
            var sql = "select * from Manager where DeFlag=0";
            if (id > 0)
            {
                //修改
                sql += $" and LoginName='{name}' and ID!={id}";
            }
            else
            {
                //新增
                sql += $" and LoginName='{name}'";
            }

            var count = _dbConnection.Query<int>(sql);
            if (count!=null&&count.Count() > 0)
            {
                return true;
            }

            return false;
        }
    }
}
