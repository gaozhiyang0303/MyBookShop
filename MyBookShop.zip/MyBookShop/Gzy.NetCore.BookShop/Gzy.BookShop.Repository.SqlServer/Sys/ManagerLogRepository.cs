﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.Core.DbHelper;
using Gzy.BookShop.Core.Option;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.IRepository.Sys;
using Gzy.BookShop.Model.Sys;
using Microsoft.Extensions.Options;

namespace Gzy.BookShop.Repository.SqlServer.Sys
{
    public class ManagerLogRepository:BaseRepository<ManagerLog,int>,IManagerLogRepository
    {
        public ManagerLogRepository(IOptionsSnapshot<DbOption> options)
        {
            //获取注册时获取的数据库类型和连接字段
            _dbOption = options.Get("Gzy.NetCore.BookShop");
            if (_dbOption == null)
            {
                throw new ArgumentNullException(nameof(options));
            }
            //调用数据库工厂类创建数据库连接通道
            _dbConnection = ConnectionFactory.CreateConnection(_dbOption.DbType, _dbOption.ConnectionString);
        }
    }
}
