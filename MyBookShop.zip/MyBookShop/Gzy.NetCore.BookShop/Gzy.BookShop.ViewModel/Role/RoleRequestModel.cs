﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.ViewModel.ResultModel;

namespace Gzy.BookShop.ViewModel.Role
{
    public class RoleRequestModel:PageModel
    {
    }
}
