﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.ViewModel.Role
{
    public class RoleViewModel
    {
        public int ID{ get; set; }
        public string RoleName { get; set; }
        public int RoleType { get; set; }//1超级管理员，2：系统管理员
        public DateTime CreatTime { get; set; }
        public string Remark { get; set; }//备注
    }
}
