﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.ViewModel.ResultModel
{
    public class BooleanResult:BaseResult
    {
        public Boolean Data { get; set; }
    }
}
