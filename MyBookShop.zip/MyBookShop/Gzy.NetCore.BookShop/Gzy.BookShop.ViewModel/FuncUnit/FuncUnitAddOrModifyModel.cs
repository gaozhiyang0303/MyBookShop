﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.ViewModel.FuncUnit
{
    public class FuncUnitAddOrModifyModel
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 父菜单ID
        /// </summary>
        public int ParentFuncUnitId { get; set; }
        public string ParentName { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 显示名称
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 图标地址
        /// </summary>
        public string IconUrl { get; set; }

        /// <summary>
        /// 链接地址
        /// </summary>
        public string LinkUrl { get; set; }

        /// <summary>
        /// 排序数字
        /// </summary>
        public int Sort { get; set; }




    


        
    }
}
