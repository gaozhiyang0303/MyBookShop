﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.ViewModel.ResultModel;

namespace Gzy.BookShop.ViewModel.Manager
{
    public class ManagerRequestModel:PageModel
    {
    }
}
