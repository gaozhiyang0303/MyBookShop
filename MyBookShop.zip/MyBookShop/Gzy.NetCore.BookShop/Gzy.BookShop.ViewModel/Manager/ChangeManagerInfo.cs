﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.ViewModel.Manager
{
    public class ChangeManagerInfo
    {
        public int ID { get; set; }
        public string LoginName { get; set; }
        public string NickName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Remark { get; set; }
        public string Avatar { get; set; }
    }
}
