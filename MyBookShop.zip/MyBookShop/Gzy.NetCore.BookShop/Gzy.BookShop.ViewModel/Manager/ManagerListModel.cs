﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.ViewModel.Manager
{
    public class ManagerListModel
    {
       public int ID { get; set; }
        public string LoginName { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
      
        public string PassWord { get; set; }
        /// <summary>
        /// 昵称
        /// </summary>
    
        public string NickName { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
 
        public string Avatar { get; set; }
        /// <summary>
        /// 手机号码
        /// </summary>
  
        public string Mobile { get; set; }
        /// <summary>
        /// 邮箱地址
        /// </summary>
        
        public string Email { get; set; }
        /// <summary>
        /// 最后一次登录IP
        /// </summary>
  
        public string LoginLastIp { get; set; }

        /// <summary>
        /// 最后一次登录时间
        /// </summary>

        public DateTime? LoginLastTime { get; set; }

        /// <summary>
        /// 添加时间
        /// </summary>
  
        public DateTime CreatTime { get; set; }

        /// <summary>
        /// 是否锁定
        /// </summary>

        public bool IsLock { get; set; }
        /// <summary>
        /// 所属角色
        /// </summary>
     
        public int ManagerRoleId { get; set; }

        public string ManagerRoleName { get; set; }

        public string Remark { get; set; }
    }
}
