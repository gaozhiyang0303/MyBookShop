﻿using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.Model.Sys;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.IRepository.Sys
{
    public interface IFuncUnitRepository : IBaseRepository<FuncUnit, int>
    {
        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="Name">别名</param>
        /// <param name="Id">主键</param>
        /// <returns></returns>
        Boolean IsExistsName(string Name, Int32 Id);

        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="Name">别名</param>
        /// <returns></returns>
        Boolean IsExistsName(string Name);

        int DeleteIds(int[] ids);
    }
}
