﻿using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.Model.Sys;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.BookShop.IRepository.Sys
{
    public interface IManagerLogRepository : IBaseRepository<ManagerLog, int>
    {
    }
}
