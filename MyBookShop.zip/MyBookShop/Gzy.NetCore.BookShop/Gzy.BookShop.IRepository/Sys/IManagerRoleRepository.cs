﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.Model.Sys;

namespace Gzy.BookShop.IRepository.Sys
{
    public interface IManagerRoleRepository:IBaseRepository<ManagerRole,int>
    {
        /// <summary>
        /// 根据登陆人的角色id获取分配给他的页面
        /// </summary>
        /// <param name="roleId"></param>
        /// <returns></returns>
        IEnumerable<FuncUnit> GetFuncUnitNav(int roleId);
        /// <summary>
        /// 判断角色名称是否重复
        /// </summary>
        /// <param name="rolename"></param>
        /// <returns></returns>
        int IsExistsRoleName(string rolename, int Id);
    }
}
