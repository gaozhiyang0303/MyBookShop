﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.Core.Repository;
using Gzy.BookShop.Model.Sys;

namespace Gzy.BookShop.IRepository.Sys
{
    public interface IManagerRepository:IBaseRepository<Manager,int>
    {
        bool IsExistsLoginName(string name,int id);
        Manager GetManagerById(int Id);
    }
}
