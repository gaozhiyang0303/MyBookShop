﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CreateDomain.Migrations
{
    public partial class Dblog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FuncUnit",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DeFlag = table.Column<bool>(nullable: false),
                    Version = table.Column<int>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 32, nullable: false),
                    ParentFuncUnitId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(maxLength: 32, nullable: false),
                    DisplayName = table.Column<string>(maxLength: 128, nullable: true),
                    IconUrl = table.Column<string>(maxLength: 128, nullable: true),
                    LinkUrl = table.Column<string>(maxLength: 128, nullable: true),
                    Sort = table.Column<int>(maxLength: 10, nullable: false),
                    Permission = table.Column<string>(maxLength: 256, nullable: true),
                    IsDisplay = table.Column<bool>(nullable: false),
                    IsSystem = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FuncUnit", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Manager",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DeFlag = table.Column<bool>(nullable: false),
                    Version = table.Column<int>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 32, nullable: false),
                    LoginName = table.Column<string>(maxLength: 32, nullable: false),
                    PassWord = table.Column<string>(maxLength: 32, nullable: false),
                    NickName = table.Column<string>(maxLength: 32, nullable: false),
                    Avatar = table.Column<string>(maxLength: 256, nullable: true),
                    Mobile = table.Column<string>(maxLength: 16, nullable: true),
                    Email = table.Column<string>(maxLength: 128, nullable: true),
                    LoginLastIp = table.Column<string>(maxLength: 64, nullable: true),
                    LoginLastTime = table.Column<DateTime>(maxLength: 23, nullable: true),
                    CreatTime = table.Column<DateTime>(nullable: false),
                    IsLock = table.Column<bool>(nullable: false),
                    ManagerRoleId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Manager", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ManagerLog",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DeFlag = table.Column<bool>(nullable: false),
                    Version = table.Column<int>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 32, nullable: false),
                    ActionType = table.Column<string>(maxLength: 32, nullable: true),
                    AddManageId = table.Column<int>(nullable: false),
                    AddManagerNickName = table.Column<string>(maxLength: 64, nullable: true),
                    AddTime = table.Column<DateTime>(maxLength: 23, nullable: false),
                    AddIp = table.Column<string>(maxLength: 64, nullable: true),
                    Remark = table.Column<string>(maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ManagerLog", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ManagerRole",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DeFlag = table.Column<bool>(nullable: false),
                    Version = table.Column<int>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 32, nullable: false),
                    RoleName = table.Column<string>(maxLength: 64, nullable: false),
                    RoleType = table.Column<int>(nullable: false),
                    IsSystem = table.Column<bool>(nullable: false),
                    CreatTime = table.Column<DateTime>(nullable: false),
                    Remark = table.Column<string>(maxLength: 128, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ManagerRole", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "RolePermission",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DeFlag = table.Column<bool>(nullable: false),
                    Version = table.Column<int>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 32, nullable: false),
                    RoleId = table.Column<int>(nullable: false),
                    FuncUnitId = table.Column<int>(nullable: false),
                    Permission = table.Column<string>(maxLength: 128, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RolePermission", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FuncUnit");

            migrationBuilder.DropTable(
                name: "Manager");

            migrationBuilder.DropTable(
                name: "ManagerLog");

            migrationBuilder.DropTable(
                name: "ManagerRole");

            migrationBuilder.DropTable(
                name: "RolePermission");
        }
    }
}
