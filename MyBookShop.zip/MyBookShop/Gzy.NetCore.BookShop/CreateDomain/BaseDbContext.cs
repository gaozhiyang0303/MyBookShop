﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.BookShop.Model.Sys;
using Microsoft.EntityFrameworkCore;

namespace CreateDomain
{
    public class BaseDbContext:DbContext
    {
        public BaseDbContext() : base()
        {

        }
        public BaseDbContext(DbContextOptions<BaseDbContext> options) : base(options)
        {

        }
        override protected void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            base.OnConfiguring(optionBuilder);
        }
        #region 数据表

        public DbSet<FuncUnit> FuncUnit { get; set; }
        public DbSet<Manager> Manager { get; set; }
        public DbSet<ManagerLog> ManagerLog { get; set; }
        public DbSet<ManagerRole> ManagerRole { get; set; }
        public DbSet<RolePermission> RolePermission { get; set; }
        #endregion
    }
}
