﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.BookShop.Model.Sys
{
    /// <summary>
    /// 角色权限
    /// 2019-03-22
    /// </summary>
    public class RolePermission:BaseEntity
    {
        /// <summary>
        /// 角色主键
        /// </summary>
        public int RoleId { get; set; }
        /// <summary>
        /// 菜单主键
        /// </summary>
        public int FuncUnitId { get; set; }
   
    }
}
