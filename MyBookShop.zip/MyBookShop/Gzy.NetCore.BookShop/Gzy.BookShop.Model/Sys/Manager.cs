﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.BookShop.Model.Sys
{
    /// <summary>
    /// 后台管理员
    /// 2019-03-22
    /// </summary>
    public partial class Manager:BaseEntity
    {        
        /// <summary>
        /// 用户名
        /// </summary>
        [Required]
        [MaxLength(32)]
        public string LoginName { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        [Required]
        [MaxLength(32)]
        public string PassWord { get; set; }
        /// <summary>
        /// 昵称
        /// </summary>
        [Required]
        [MaxLength(32)]
        public string NickName { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        [MaxLength(256)]
        public string Avatar { get; set; }
        /// <summary>
        /// 手机号码
        /// </summary>
        [MaxLength(16)]
        public string Mobile { get; set; }
        /// <summary>
        /// 邮箱地址
        /// </summary>
        [MaxLength(128)]
        public string Email { get; set; }
        /// <summary>
        /// 最后一次登录IP
        /// </summary>
        [MaxLength(64)]
        public string LoginLastIp { get; set; }

        /// <summary>
        /// 最后一次登录时间
        /// </summary>
        [MaxLength(23)]
        public DateTime? LoginLastTime { get; set; }

        /// <summary>
        /// 添加时间
        /// </summary>
        [Required]
        public DateTime CreatTime { get; set; }

        /// <summary>
        /// 是否锁定
        /// </summary>
        [Required]
        public bool IsLock { get; set; }
        /// <summary>
        /// 所属角色
        /// </summary>
        [Required]
        public int ManagerRoleId { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
