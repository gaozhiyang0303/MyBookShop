﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.BookShop.Model.Sys
{
    /// <summary>
    /// 后台管理员角色
    /// 2019-03-22
    /// </summary>
    public class ManagerRole:BaseEntity
    {
        /// <summary>
        /// 角色名称
        /// </summary>
        [Required]
        [MaxLength(64)]
        public string RoleName { get; set; }
        /// <summary>
        /// 角色类型 1超管 2系管
        /// </summary>
        [Required]     
        public int RoleType { get; set; }


        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreatTime { get; set; }

        // <summary>
        /// 备注
        /// </summary>
        [MaxLength(128)]
        public string Remark { get; set; }
    }
}
