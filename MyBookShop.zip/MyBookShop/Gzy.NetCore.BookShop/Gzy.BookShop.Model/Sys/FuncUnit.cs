﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.BookShop.Model.Sys
{
    /// <summary>
    /// 后台管理菜单
    /// 2019-03-22
    /// </summary>
    public class FuncUnit:BaseEntity
    {
        /// <summary>
        /// 父菜单Id
        /// </summary>
        [Required]
        public int ParentFuncUnitId { get; set; }
        /// <summary>
        /// 菜单名称
        /// </summary>
        [Required]
        [MaxLength(32)]
        public string Name { get; set; }

        /// <summary>
        /// 显示名称
        /// </summary>
        [MaxLength(128)]
        public string DisplayName { get; set; }

        /// <summary>
        /// 图标地址
        /// </summary>
        [MaxLength(128)]
        public string IconUrl { get; set; }

        /// <summary>
        /// 链接地址
        /// </summary>
        [MaxLength(128)]
        public string LinkUrl { get; set; }

        /// <summary>
        /// 排序数字
        /// </summary>
        [MaxLength(10)]
        public int Sort { get; set; }

      

      
    }
}
