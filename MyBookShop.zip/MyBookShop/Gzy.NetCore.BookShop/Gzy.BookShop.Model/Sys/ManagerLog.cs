﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.BookShop.Model.Sys
{
    /// <summary>
    /// 后台管理员操作日志
    /// 2019-03-22
    /// </summary>
    public class ManagerLog:BaseEntity
    {
        /// <summary>
        /// 操作类型
        /// </summary>
        [MaxLength(32)]
        public string ActionType { get; set; }

        /// <summary>
        /// 主键
        /// </summary>
        [Required]
        public int AddManageId { get; set; }

        /// <summary>
        /// 操作人名称
        /// </summary>
        [MaxLength(64)]
        public string AddManagerNickName { get; set; }

        /// <summary>
        /// 操作时间
        /// </summary>
        [Required]
        [MaxLength(23)]
        public DateTime AddTime { get; set; }

        /// <summary>
        /// 操作IP
        /// </summary>
        [MaxLength(64)]
        public string AddIp { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        [MaxLength(256)]
        public string Remark { get; set; }
    }
}
