﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.BookShop.Model
{
    /// <summary>
    /// 基础实体类
    /// 2019-03-22
    /// </summary>
    public class BaseEntity
    {
        [Key]
        public int ID { get; set; }
        public bool DeFlag { get; set; }
        public int Version { get; set; }
        public DateTime OptDate { get; set; } = DateTime.Now;
        [Required]
        [MaxLength(32)]
        public string OptUser { get; set; }
    }
}
