﻿using FluentValidation;
using Gzy.BookShop.ViewModel.FuncUnit;
  
namespace Gzy.NetCore.BookShop.Validation
{
    public class FuncUnitValidation: AbstractValidator<FuncUnitAddOrModifyModel>
    {
        public FuncUnitValidation()
        {
            CascadeMode = CascadeMode.StopOnFirstFailure;

            RuleFor(x => x.ParentFuncUnitId).NotNull().WithMessage("上级菜单不能为空");
            RuleFor(x => x.Name).NotEmpty().Length(5, 32).WithMessage("菜单别名不能为空且最大长度不能超过32个字符");
            RuleFor(x => x.DisplayName).Length(0, 64).WithMessage("菜单显示名称长度不能超过64个字符");
            RuleFor(x => x.IconUrl).Length(0, 128).WithMessage("菜单显示名称长度不能超过128个字符");
            RuleFor(x => x.LinkUrl).Length(0, 128).WithMessage("菜单显示名称长度不能超过128个字符");
            
        }
    }
}
