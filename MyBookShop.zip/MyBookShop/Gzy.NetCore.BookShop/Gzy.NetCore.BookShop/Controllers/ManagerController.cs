﻿using Gzy.BookShop.Core;
using Gzy.BookShop.Core.Extensions;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.Manager;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using Gzy.BookShop.Model.Sys;
using Gzy.BookShop.ViewModel.ResultModel;
using Microsoft.AspNetCore.Http;

namespace Gzy.NetCore.BookShop.Controllers
{
    public class ManagerController : BaseController
    {
        private readonly IHostingEnvironment hostingEnv;
        private readonly IManagerService _service;
        private readonly IManagerRoleService _roleservice;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ManagerController(IManagerService service, IManagerRoleService roleservice,IHostingEnvironment hostingEnv, IHttpContextAccessor httpContextAccessor)
        {
            _service = service;
            _roleservice = roleservice;
            this.hostingEnv = hostingEnv;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public string LoadData([FromQuery]ManagerRequestModel model)
        {
            var data=_service.LoadData(model);
            return JsonHelper.ObjectToJSON(data);
        }
       
        [HttpGet]
        public IActionResult AddOrModify()
        {
            var datas = _roleservice.GetRoleViewModels();
            return View(datas);
        }

        [HttpPost]
        public string AddOrModify([FromForm]ManagerListModel item)
        {
       
            var result=_service.AddOrUpdateManager(item);
            return JsonHelper.ObjectToJSON(result);
        }

        [HttpGet]
        public bool IsExistsLoginName(string Name,int ID)
        {
            return _service.IsExistsLoginName(Name, ID);
        }

        public IActionResult ManagerInfo()
        {
            var id = User.Claims.FirstOrDefault(p => p.Type == "ID");
            if (id == null)
            {
                return RedirectToAction("SignOutAsync", "Account");
            }

            var model = _service.GetManagerById(int.Parse(id.Value));
            if (model == null)
            {
                return RedirectToAction("SignOut", "Account");
            }
            //model.Avatar = model.Avatar ?? "/images/userface1.jpg";
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public string ManagerInfo([FromForm]ChangeManagerInfo item)
        {
            var result = new BaseResult();
            if (ModelState.IsValid)
            {
                result = _service.UpdateManagerInfo(item);
                _httpContextAccessor.HttpContext.Session.SetString("NickName", item.NickName ?? "匿名");
                _httpContextAccessor.HttpContext.Session.SetString("Email", item.Email ?? "");
                _httpContextAccessor.HttpContext.Session.SetString("Avatar", item.Avatar ?? "/images/userface1.jpg");
                _httpContextAccessor.HttpContext.Session.SetString("Mobile", item.Mobile ?? "");
            }
            else
            {
                result.ResultCode = ResultCodeAddMsgKeys.CommonModelStateInvalidCode;
                result.ResultMsg = ToErrorString(ModelState, "||");
            }
            return JsonHelper.ObjectToJSON(result);
        }
        [HttpPost]
        public IActionResult UploaduserFace()
        {
            #region 文件上传
            var imgFile = Request.Form.Files[0];
            if (imgFile != null && !imgFile.FileName.IsNullOrEmpty())
            {
                long size = 0;
                string tempname = "";
                var filename = ContentDispositionHeaderValue
                                .Parse(imgFile.ContentDisposition)
                                .FileName
                                .Trim('"');
                var extname = filename.Substring(filename.LastIndexOf("."), filename.Length - filename.LastIndexOf("."));
                #region 判断后缀
                //if (!extname.ToLower().Contains("jpg") && !extname.ToLower().Contains("png") && !extname.ToLower().Contains("gif"))
                //{
                //    return Json(new { code = 1, msg = "只允许上传jpg,png,gif格式的图片.", });
                //}
                #endregion
                #region 判断大小
                long mb = imgFile.Length / 1024 / 1024; // MB
                if (mb > 1)
                {
                    return Json(new { code = 1, msg = "只允许上传小于 1MB 的图片.", });
                }
                #endregion
                var filename1 = DateTime.Now.ToString("yyyyMMddHHmmssfff") + new Random().Next(1000, 9999) + extname;
                tempname = filename1;
                var path = hostingEnv.WebRootPath;
                string dir = DateTime.Now.ToString("yyyyMMdd");
                if (!Directory.Exists(hostingEnv.WebRootPath + $@"\upload\{dir}"))
                {
                    Directory.CreateDirectory(hostingEnv.WebRootPath + $@"\upload\{dir}");
                }
                filename = hostingEnv.WebRootPath + $@"\upload\{dir}\{filename1}";
                size += imgFile.Length;
                using (FileStream fs = System.IO.File.Create(filename))
                {
                    imgFile.CopyTo(fs);
                    fs.Flush();
                }
                return Json(new { code = 0, msg = "上传成功", data = new { src = $"/upload/{dir}/{filename1}", title = "图片标题" } });
            }
            return Json(new { code = 1, msg = "上传失败", });
            #endregion
        }
    }
}