﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation.Results;
using Gzy.BookShop.Core;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.FuncUnit;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.NetCore.BookShop.Validation;
using Microsoft.AspNetCore.Mvc;

namespace Gzy.NetCore.BookShop.Controllers
{
    public class FuncUnitController : BaseController
    {
        private readonly IFuncUnitService _service;
       
        public FuncUnitController(IFuncUnitService service)
        {
            _service = service;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public string LoadData([FromQuery]FuncUnitRequestModel model)
        {
            var data= _service.LoadData(model); 
            return JsonHelper.ObjectToJSON(data);
        }
        //添加
        [HttpGet]
        public IActionResult AddOrModify()
        {
            return View(_service.GetChildListByParentId());
        }

        [HttpPost]
        public string AddOrModify([FromForm]FuncUnitAddOrModifyModel item)
        {
            var result = new BaseResult();
            FuncUnitValidation validationRules = new FuncUnitValidation();
            ValidationResult results = validationRules.Validate(item);
            if (results.IsValid)
            {
                result = _service.AddOrModify(item);
            }
            else
            {
                result.ResultCode = ResultCodeAddMsgKeys.CommonModelStateInvalidCode;
                result.ResultMsg = results.ToString("||");
            }
            return JsonHelper.ObjectToJSON(result);
        }
        [HttpGet]
        public string IsExistsName([FromQuery]FuncUnitAddOrModifyModel item)
        {
            var result = _service.IsExistsName(item);
            return JsonHelper.ObjectToJSON(result);
        }

        [HttpPost]
        public string Delete(int[] ids)
        {
            return JsonHelper.ObjectToJSON(_service.DeleteIds(ids));
        }
    }
}