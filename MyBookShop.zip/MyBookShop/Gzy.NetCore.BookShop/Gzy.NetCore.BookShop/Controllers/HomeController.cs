﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Gzy.NetCore.BookShop.Models;
using Gzy.BookShop.Core;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.Core.Extensions;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace Gzy.NetCore.BookShop.Controllers
{
   
    public class HomeController : BaseController
    {
        private readonly IManagerRoleService _managerRoleService;
        public HomeController(IManagerRoleService managerRoleService)
        {
            _managerRoleService = managerRoleService;
        }
        public IActionResult Index()
        {
            ViewData["NickName"] = HttpContext.Session.GetString("NickName");
            ViewData["Avatar"] = HttpContext.Session.GetString("Avatar");
            return View();
        }

        public IActionResult Main()
        {
            return View();
        }
        public string GetFuncUnit()
        {
            var roleId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Role)?.Value;
            var navViewTree = _managerRoleService.GetFuncUnitsByRoleId(1).GenerateTree(x => x.Id, x => x.ParentId);
            return JsonHelper.ObjectToJSON(navViewTree);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
