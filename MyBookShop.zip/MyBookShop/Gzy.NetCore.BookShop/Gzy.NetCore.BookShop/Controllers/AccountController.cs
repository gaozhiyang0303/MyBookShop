﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Gzy.BookShop.Core;
using Gzy.BookShop.Core.Extensions;
using Gzy.BookShop.Core.Helper;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.Account;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.CorePublic;
using Gzy.NetCore.BookShop.Validation;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Gzy.NetCore.BookShop.Controllers
{

    public class AccountController : Controller
    {
        private readonly string CaptchaCodeSessionName = "CaptchaCode";
        private IManagerService _service;
        private IHttpContextAccessor _iHttpContextAccessor;
        public AccountController(IManagerService service, IHttpContextAccessor iHttpContextAccessor)
        {
            _service = service;
            _iHttpContextAccessor = iHttpContextAccessor;
        }
        public IActionResult Index()
        {
            return View();
        }
      
        public IActionResult GetCaptchaImage()
        {

            string captchaCode = CaptchaHelper.GenerateCaptchaCode();
            var result = CaptchaHelper.GetImage(116, 36, captchaCode);
            HttpContext.Session.SetString(CaptchaCodeSessionName, captchaCode);
            return new FileStreamResult(new MemoryStream(result.CaptchaByteData), "image/png");
        }
        [HttpPost,ValidateAntiForgeryToken]
        public async Task<string> Login(LoginViewModel model)
        {
            BaseResult result = new BaseResult();
            model.Ip =HttpContext.GetClientUserIp();

            #region 判断验证码是否错误
            if (!VaildCaptchaCode(model.CaptchaCode))
            {
                result.ResultCode = ResultCodeAddMsgKeys.SignInCaptchaCodeErrorCode;
                result.ResultMsg = ResultCodeAddMsgKeys.SignInCaptchaCodeErrorMsg;
                return JsonHelper.ObjectToJSON(result);
            }
            #endregion
            #region 再次进行数据校验

            var validation = new LoginModelValidation();
            var res = validation.Validate(model);
            if (!res.IsValid)
            {
                result.ResultCode = ResultCodeAddMsgKeys.CommonModelStateInvalidCode;
                result.ResultMsg = ResultCodeAddMsgKeys.CommonModelStateInvalidMsg;
                return JsonHelper.ObjectToJSON(result);
            }
            #endregion

            //_service.SignIn(model);
            //model.Password = GzyCryptography.GetMd5Hash(model.Password.Trim());
            var manager=_service.SignIn(model);
            if (manager == null)
            {
                result.ResultCode = ResultCodeAddMsgKeys.SignInPasswordOrUserNameErrorCode;
                result.ResultMsg = ResultCodeAddMsgKeys.SignInPasswordOrUserNameErrorMsg;
            }else if (manager.IsLock)
            {
                result.ResultCode = ResultCodeAddMsgKeys.SignInUserLockedCode;
                result.ResultMsg = ResultCodeAddMsgKeys.SignInUserLockedMsg;
            }
            else
            {
                //cookie
                var claim=new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, manager.LoginName),
                    new Claim(ClaimTypes.Role, manager.ManagerRoleId.ToString()),

                    new Claim("ID",manager.ID.ToString()),
                    new Claim("LoginLastIp",manager.LoginLastIp),
                    new Claim("LoginLastTime",manager.LoginLastTime?.ToString("yyyy-MM-dd HH:mm:ss")),
                };
                var claimIdentiy=new ClaimsIdentity(claim,CookieAuthenticationDefaults.AuthenticationScheme);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimIdentiy));

                //进行Session存储
                _iHttpContextAccessor.HttpContext.Session.SetInt32("ID", manager.ID);
                _iHttpContextAccessor.HttpContext.Session.SetInt32("RoleId", manager.ManagerRoleId);
                _iHttpContextAccessor.HttpContext.Session.SetString("NickName", manager.NickName ?? "匿名");
                _iHttpContextAccessor.HttpContext.Session.SetString("Email", manager.Email ?? "");
                _iHttpContextAccessor.HttpContext.Session.SetString("Avatar", manager.Avatar ?? "/images/userface1.jpg");
                _iHttpContextAccessor.HttpContext.Session.SetString("Mobile", manager.Mobile ?? "");
            }
            return JsonHelper.ObjectToJSON(result);
        }
        [Route("Account/SignOut")]
        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index");
        }

        public bool VaildCaptchaCode(string code)
        {
            var captchaCode = HttpContext.Session.GetString(CaptchaCodeSessionName);
            if (string.IsNullOrEmpty(captchaCode))
            {
                return false;//session存储失效
            }
            if (!string.Equals(code,captchaCode, StringComparison.CurrentCultureIgnoreCase))
            {
                return false;
            }

            return true;



        }

        
    }
}