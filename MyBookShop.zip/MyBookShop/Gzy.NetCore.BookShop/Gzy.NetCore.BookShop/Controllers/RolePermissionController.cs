﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gzy.BookShop.Core;
using Gzy.BookShop.IService.Sys;
using Microsoft.AspNetCore.Mvc;

namespace Gzy.NetCore.BookShop.Controllers
{
    public class RolePermissionController : Controller
    {
        private readonly IRolePermissionService _service;

        public RolePermissionController(IRolePermissionService service)
        {
            _service = service;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public string LoadFuncUnit(int Id)
        {
            var data=_service.GetRoleFuncUnits(Id);
            return JsonHelper.ObjectToJSON(data);
        }

        [HttpPost]
        public string RoleBindingFunc(int[] ids,int roleId)
        {
           var data= _service.RoleBindingFunc(ids, roleId);
           return JsonHelper.ObjectToJSON(data);
        }
    }
}