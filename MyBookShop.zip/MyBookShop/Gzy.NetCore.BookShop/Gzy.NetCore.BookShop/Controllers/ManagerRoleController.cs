﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gzy.BookShop.Core;
using Gzy.BookShop.IService.Sys;
using Gzy.BookShop.ViewModel.ResultModel;
using Gzy.BookShop.ViewModel.Role;
using Microsoft.AspNetCore.Mvc;

namespace Gzy.NetCore.BookShop.Controllers
{
    public class ManagerRoleController : BaseController
    {
        private IManagerRoleService _service;

        public ManagerRoleController(IManagerRoleService service)
        {
            _service = service;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public string LoadData([FromQuery]RoleRequestModel model)
        {
            var data = _service.GetRoleList(model);
            return JsonHelper.ObjectToJSON(data);
        }
        //添加页面
        [HttpGet]
        public IActionResult AddOrModify()
        {
            
            return View();
        }

        [HttpPost]
        public string AddOrModify([FromForm] RoleViewModel item)
        {
            var res=_service.SaveOrUpdateRole(item);
            return JsonHelper.ObjectToJSON(res);
        }
    }
}