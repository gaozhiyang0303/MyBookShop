﻿layui.use(['form', 'layer', 'table', 'laytpl'], function () {
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,
        laytpl = layui.laytpl,
        table = layui.table;
    //角色列表
    table.render({
        elem: '#roleList',
        url: '/ManagerRole/LoadData/',
        cellMinWidth: 95,
        page: true, //是否分页
        height: "full-10",
        limits: [10, 15, 20, 25],
        limit: 10,
        id: "roleListTable",
        cols: [
            [
                
                { field: "ID", title: 'ID', minWidth: 50, align: "center" },
                { field: 'RoleName', title: '角色名称', minWidth: 100, align: "center" },
            ]
        ],
    });
    var roleid;
    //监听行单击事件（单击事件为：rowDouble）
    table.on('row(roleList)', function (obj) {
        var data = obj.data;
        roleid = data.ID;
        //标注选中样式
        obj.tr.addClass('layui-table-click').siblings().removeClass('layui-table-click');
        //table = $.extend(table, { config: { checkName: 'IsCheck' } });
        table.render({
            elem: '#funcUnitList',
            url: '/RolePermission/LoadFuncUnit/' + data.ID,
            page: true,
            height: "full-95",
            limits: [10, 15, 20, 25],
            limit: 10,
            id: "funcUnitListTable",
            cols: [[
                {
                    type: "checkbox", fixed: "left", width: 50
                },
                { field: "Id", title: 'Id', minWidth: 30, align: "center" },
                { field: 'Name', title: '调用别名', minWidth: 100, align: "center" },
                { field: 'DisplayName', title: '显示名称', minWidth: 100, align: "center" },
                { field: 'LinkUrl', title: '链接地址', minWidth: 100, align: "center" },
                { field: 'Sort', title: '排序数字', minWidth: 100, align: 'center' },
                { field: 'ParentName', title: '所属菜单', minWidth: 80, align: "center" },
            ]]
        });
        //工具栏事件
        table.on('toolbar(funcUnitList)', function (obj) {
            var checkStatus = table.checkStatus(2);

        });
        //$.ajax({
        //    type: 'POST',
        //    url: '/RolePermission/LoadFuncUnit/',
        //    data: {
        //        Id: data.ID,  //所选择的角色ID              
        //    },
        //    dataType: "json",
        //    headers: {
        //        "X-CSRF-TOKEN-yilezhu": $("input[name='AntiforgeryKey_yilezhu']").val()
        //    },
        //    success: function (res) {//res为相应体,function为回调函数
                
        //    },
        //    error: function (XMLHttpRequest, textStatus, errorThrown) {
        //        layer.alert('操作失败！！！' + XMLHttpRequest.status + "|" + XMLHttpRequest.readyState + "|" + textStatus, { icon: 5 });
        //    }
        //});

        
    });
   
    $(".addRolePermis_btn").click(function () {
        var checkStatus = table.checkStatus('funcUnitListTable'),
            data = checkStatus.data,
            roleId = [];
        if (data.length > 0) {
            for (var i in data) {
                roleId.push(data[i].Id);
            }
            layer.confirm('确定分配选中的菜单？', { icon: 3, title: '提示信息' }, function (index) {
                //获取防伪标记
                RoleBindingFunc(roleId);
            });
        } else {
            layer.msg("请选择需要分配的菜单");
        }
    });
    function RoleBindingFunc(ids) {
        $.ajax({
            type: 'POST',
            url: '/RolePermission/RoleBindingFunc/',
            data: {
                ids: ids,
                roleId: roleid

            },
            dataType: "json",
            headers: {
                "X-CSRF-TOKEN-yilezhu": $("input[name='AntiforgeryKey_yilezhu']").val()
            },
            success: function (data) {//res为相应体,function为回调函数
                layer.msg(data.ResultMsg, {
                    time: 2000 //20s后自动关闭
                }, function () {
                    tableIns.reload();
                    layer.close(index);
                });
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.alert('操作失败！！！' + XMLHttpRequest.status + "|" + XMLHttpRequest.readyState + "|" + textStatus, { icon: 5 });
            }
        });
    }

   
})