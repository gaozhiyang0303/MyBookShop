﻿layui.use(['form', 'layer', 'table', 'laytpl'], function() {
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,
        laytpl = layui.laytpl,
        table = layui.table;
    var table = table.render({
        elem: '#managerList',
        url: '/Manager/LoadData/',
        cellMinWidth: 95,
        page: true,
        height: "full-95",
        limits: [10, 15, 20, 25],
        limit: 10,
        id: "managerListTable",
        cols: [
            [
                { type: "checkbox", fixed: "left", width: 50 },
                { field: "ID", title: 'ID', width: 50, align: "center" },
                { field: 'LoginName', title: '登陆ID', minWidth: 50, align: "center" },
                { field: 'NickName', title: '用户昵称', minWidth: 50, align: "center" },
                { field: 'Mobile', title: '手机号码', minWidth: 80, align: "center" },
                { field: 'Email', title: '邮箱地址', minWidth: 100, align: "center" },
                { field: 'ManagerRoleName', title: '所属角色', minWidth: 80, align: 'center' },
                { field: 'Remark', title: '备注', align: 'center' },
                { field: 'IsLock', title: '是否锁定', minWidth: 100, fixed: "right", align: "center", templet: '#IsLock' },
                { title: '操作', minWidth: 80, templet: '#managerListBar', fixed: "right", align: "center" }
            ]
        ]
    })
    $(".addmanager_btn").click(function() {
        addmanager();
    });

    function addmanager(edit) {
        var tit = "添加菜单";
        if (edit) {
            tit = "编辑菜单";
        }
        layui.layer.open({
            title: tit,
            type: 2,
            anim: 1,
            area: ['500px', '90%'],
            content: "/Manager/AddOrModify/",
            success: function(layero, index) {
                var body = layui.layer.getChildFrame('body', index);
                if (edit) {
                    body.find("#ID").val(edit.Id);
                    body.find(".LoginName").val(edit.UserName);
                    body.find(".NickName").val(edit.NickName);
                    body.find(".ManagerRoleId").val(edit.RoleId);
                    body.find(".Mobile").val(edit.Mobile);
                    body.find(".Email").val(edit.Email);
                    body.find("input:checkbox[name='IsLock']").prop("checked", edit.IsLock);
                    body.find(".Remark").text(edit.Remark);
                    form.render();
                }
            }
        })
    }
});