﻿layui.use(['form', 'layer', 'table'], function() {
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,
        table = layui.table;
    //菜单列表
    var tableIns = table.render({
        elem: '#funcUnitList',
        url: '/FuncUnit/LoadData/',
        cellMinWidth: 95,
        page: true,
        height: "full-95",
        limits: [10, 15, 20, 25],
        limit: 10,
        id: "funcUnitListTable",
        cols: [[
            { type: "checkbox", fixed: "left", width: 50 },
            { field: "Id", title: 'Id', minWidth: 30, align: "center" },
            { field: 'Name', title: '调用别名', minWidth: 50, align: "center" },
            { field: 'DisplayName', title: '显示名称', minWidth: 50, align: "center" },
            { field: 'LinkUrl', title: '链接地址', minWidth: 80, align: "center" },
            { field: 'Sort', title: '排序数字', minWidth: 80, align: 'center' },
            //{ field: 'IsDisplay', title: '是否显示', minWidth: 100, fixed: "right", align: "center", templet: '#IsDisplay' },
            { field: 'ParentName', title: '所属菜单', minWidth: 80, align: "center" },
            { title: '操作', minWidth: 80, templet: '#funcUnitListBar', fixed: "right", align: "center" }
        ]]
    });
    //搜索【此功能需要后台配合，所以暂时没有动态效果演示】
    $(".search_btn").on("click", function () {
        table.reload("funcUnitListTable", {
            page: {
                curr: 1 //重新从第 1 页开始
            },
            where: {
                key: $(".searchVal").val()  //搜索的关键字
                
            }
            
        });
        //if ($(".searchVal").val() !== '') {
            
        //} else {
        //    layer.msg("请输入搜索的内容");
        //}
    });
    
    

    //添加菜单
    $(".addFuncUnit_btn").click(function () {
        addFuncUnit();
    });
    function addFuncUnit(edit) {
        var tit = "添加菜单";
        if (edit) {
            tit = "编辑菜单";
        }
        var index = layui.layer.open({
            title: tit,
            type: 2,
            anim: 1,
            area: ['600px', '80%'],
            content: "/FuncUnit/AddOrModify/",
            success: function (layero, index) {
                var body = layui.layer.getChildFrame('body', index);
                if (edit) {
                    body.find("#Id").val(edit.Id);
                    body.find(".Name").val(edit.Name);
                    body.find(".DisplayName").val(edit.DisplayName);
                    body.find(".IconUrl").val(edit.IconUrl);
                    body.find(".LinkUrl").val(edit.LinkUrl);
                    body.find(".Sort").val(edit.Sort);
                    body.find(".DisplayName").val(edit.DisplayName);
               
                    body.find(".ParentFuncUnitId").val(edit.ParentFuncUnitId);
                    //alert(edit.ParentFuncUnitId);
                    body.find(".Remark").text(edit.Remark);    //角色备注
                    form.render();

                }
            }
        });
    }
    //批量删除
    $(".delAll_btn").click(function () {
        var checkStatus = table.checkStatus('funcUnitListTable'),
            data = checkStatus.data,
            roleId = [];
        if (data.length > 0) {
            for (var i in data) {
                roleId.push(data[i].Id);
            }
            layer.confirm('确定删除选中的菜单？', { icon: 3, title: '提示信息' }, function (index) {
                //获取防伪标记
                del(roleId);
            });
        } else {
            layer.msg("请选择需要删除的菜单");
        }
    });

    //列表操作
    table.on('tool(funcUnitList)', function (obj) {
        var layEvent = obj.event,
            data = obj.data;

        if (layEvent === 'edit') { //编辑
            addFuncUnit(data);
        } else if (layEvent === 'del') { //删除
            layer.confirm('确定删除此菜单？', { icon: 3, title: '提示信息' }, function (index) {
                del(data.Id);
            });
        }
    });

    function del(ids) {
        $.ajax({
            type: 'POST',
            url: '/FuncUnit/Delete/',
            data: { ids: ids },
            dataType: "json",
            headers: {
                "X-CSRF-TOKEN-yilezhu": $("input[name='AntiforgeryKey_yilezhu']").val()
            },
            success: function (data) {//res为相应体,function为回调函数
                layer.msg(data.ResultMsg, {
                    time: 2000 //20s后自动关闭
                }, function () {
                    tableIns.reload();
                    layer.close(index);
                });
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.alert('操作失败！！！' + XMLHttpRequest.status + "|" + XMLHttpRequest.readyState + "|" + textStatus, { icon: 5 });
            }
        });
    }

  

    
});
