﻿layui.use(['form', 'layer', 'table', 'laytpl'], function () {
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,
        laytpl = layui.laytpl,
        table = layui.table;
    //角色列表
    var tables = table.render({
        elem: '#roleList',
        url: '/ManagerRole/LoadData/',
        cellMinWidth: 95,
        page: true, //是否分页
        height: "full-95",
        limits: [10, 15, 20, 25],
        limit: 10,
        id: "roleListTable",
        cols: [
            [
                { type: "checkbox", fixed: "left", width: 50 },
                { field: "ID", title: 'ID', minWidth: 50, align: "center" },
                { field: 'RoleName', title: '角色名称', minWidth: 100, align: "center" },
              
                { field: 'CreatTime', title: '创建时间', minWidth: 100, align: 'center' },
                { field: 'Remark', title: '备注', minWidth: 100, align: "center" },
                { title: '操作', minWidth: 100, templet: '#roleListBar', fixed: "right", align: "center" }
            ]
        ],
    });
    //监听行单击事件（单击事件为：rowDouble）
    //table.on('row(roleList)', function (obj) {
    //    var data = obj.data;

    //    layer.alert(JSON.stringify(data), {
    //        title: '当前行数据：'
    //    });

    //    //标注选中样式
    //    obj.tr.addClass('layui-table-click').siblings().removeClass('layui-table-click');
    //});
    //搜索【此功能需要后台配合，所以暂时没有动态效果演示】
    $(".search_btn").on("click", function () {
        table.reload("roleListTable", {
            page: {
                curr: 1 //重新从第 1 页开始
            },
            where: {
                key: $(".searchVal").val()  //搜索的关键字

            }

        });
        
    });
    //添加菜单
    $(".addRole_btn").click(function () {
        addRole();
    });

    function addRole(edit) {
        var tit = "添加菜单";
        if (edit) {
            tit = "编辑菜单";
        }
        var index = layui.layer.open({
            title: tit,
            type: 2,
            anim: 1,
            area: ['600px', '80%'],
            content: "/ManagerRole/AddOrModify/",
            success: function (layero, index) {
                var body = layui.layer.getChildFrame('body', index);
                if (edit) {
                    body.find("#ID").val(edit.ID);
                    body.find(".RoleName").val(edit.RoleName);
                    body.find(".RoleType").val(edit.RoleType);        
                    body.find(".Remark").text(edit.Remark);    //角色备注
                    form.render();

                }
            }
        });
    }
})